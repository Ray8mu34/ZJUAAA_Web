(() => {
  'use strict';
  const root = document.documentElement;
  const header = document.querySelector('[data-header]');
  const hero = document.querySelector('[data-hero]');
  const dialog = document.querySelector('#site-menu');
  const openButton = document.querySelector('[data-menu-open]');
  const closeButton = document.querySelector('[data-menu-close]');
  const fallback = document.querySelector('.menu-fallback');
  const params = new URLSearchParams(location.search);
  const presets = Array.isArray(window.HERO_PRESETS) ? window.HERO_PRESETS : [];
  const p = presets.find(item => item.id === (params.get('style') || '02')) ||
    presets.find(item => item.id === '02');
  if (p) {
    root.dataset.style = p.id;
    root.style.setProperty('--hero-surface', p.continuationSurface);
    root.style.setProperty('--hero-ink', p.surfaceTone === 'light' ? '#101e30' : '#f8f0e3');
    root.style.setProperty('--brand-ink', p.navBrandTone === 'ink' ? '#172b43' : '#f8f0e3');
    root.style.setProperty('--menu-ink', p.navMenuTone === 'ink' ? '#172b43' : '#f8f0e3');
    document.querySelector('.hero-img').src = p.previewImage;
  }
  function setTheme(theme) {
    root.dataset.theme = theme === 'light' ? 'light' : 'dark';
    document.querySelectorAll('[data-theme-choice]').forEach(button =>
      button.setAttribute('aria-pressed', String(button.dataset.themeChoice === root.dataset.theme)));
    try { localStorage.setItem('zjua-design-theme', root.dataset.theme); } catch (_) {}
  }
  let initial = 'dark';
  try { initial = localStorage.getItem('zjua-design-theme') || 'dark'; } catch (_) {}
  setTheme(params.get('theme') || initial);
  document.querySelectorAll('[data-theme-choice]').forEach(button =>
    button.addEventListener('click', () => setTheme(button.dataset.themeChoice)));

  let ticking = false, observer;
  function sync() {
    ticking = false;
    if (dialog.open) return;
    const content = hero.getBoundingClientRect().bottom <= header.offsetHeight;
    header.dataset.state = content ? 'content' : scrollY > 16 ? 'scroll' : 'cover';
  }
  function connectObserver() {
    observer?.disconnect();
    if ('IntersectionObserver' in window) {
      observer = new IntersectionObserver(sync, {
        rootMargin: `-${header.offsetHeight}px 0px 0px 0px`, threshold: 0
      });
      observer.observe(hero);
    }
    sync();
  }
  addEventListener('scroll', () => {
    if (!ticking) { ticking = true; requestAnimationFrame(sync); }
  }, { passive: true });
  addEventListener('resize', connectObserver);
  addEventListener('pageshow', connectObserver);
  connectObserver();

  let opener = null, lock = null, closeAction = null;
  function lockPage() {
    if (lock) return;
    lock = { x: scrollX, y: scrollY, overflow: root.style.overflow,
      position: document.body.style.position, top: document.body.style.top,
      left: document.body.style.left, right: document.body.style.right,
      width: document.body.style.width };
    root.style.overflow = 'hidden';
    Object.assign(document.body.style, {
      position: 'fixed', top: `-${lock.y}px`, left: '0', right: '0', width: '100%'
    });
  }
  function unlockPage() {
    if (!lock) return;
    const saved = lock; lock = null;
    root.style.overflow = saved.overflow;
    for (const key of ['position', 'top', 'left', 'right', 'width'])
      document.body.style[key] = saved[key];
    scrollTo({ left: saved.x, top: saved.y, behavior: 'instant' });
  }
  function targetFor(hash) {
    if (!hash || !hash.startsWith('#')) return null;
    try { return document.getElementById(decodeURIComponent(hash.slice(1))); }
    catch (_) { return null; }
  }
  function visitAnchor(hash) {
    const target = targetFor(hash);
    if (!target) return;
    // Hash-only URL, plus a native fallback, also works when opened directly via file://.
    try { history.pushState(null, '', hash); } catch (_) { location.hash = hash; }
    if (!target.hasAttribute('tabindex')) target.setAttribute('tabindex', '-1');
    target.focus({ preventScroll: true });
    const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
    target.scrollIntoView({ behavior: reduced ? 'instant' : 'smooth', block: 'start' });
    sync();
  }
  if (typeof dialog.showModal === 'function') {
    openButton.addEventListener('click', () => {
      if (dialog.open) return;
      opener = document.activeElement;
      closeAction = null;
      lockPage();
      try {
        dialog.showModal();
        openButton.setAttribute('aria-expanded', 'true');
        closeButton.focus({ preventScroll: true });
      } catch (_) {
        unlockPage();
        openButton.hidden = true; fallback.hidden = false;
        root.classList.remove('nav-enhanced');
        location.hash = 'site-index';
      }
    });
    closeButton.addEventListener('click', () => dialog.close());
    // The native dialog handles Escape and modal focus containment.
    dialog.addEventListener('close', () => {
      const action = closeAction; closeAction = null;
      unlockPage();
      openButton.setAttribute('aria-expanded', 'false');
      if (action?.hash) visitAnchor(action.hash);
      else if (!action?.navigating && opener?.isConnected) opener.focus({ preventScroll: true });
      sync();
    });
    dialog.querySelectorAll('[data-menu-link]').forEach(link => link.addEventListener('click', event => {
      if (event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey ||
          event.shiftKey || event.altKey || (link.target && link.target !== '_self')) return;
      const href = link.getAttribute('href');
      if (targetFor(href)) {
        event.preventDefault();
        closeAction = { hash: href };
      } else closeAction = { navigating: true };
      dialog.close();
    }));
    // Keep the plain menu link functional until enhanced navigation is fully initialized.
    root.classList.add('nav-enhanced');
    openButton.hidden = false;
    fallback.hidden = true;
  }
  document.querySelector('.continue').addEventListener('click', event => {
    if (event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
    event.preventDefault();
    visitAnchor('#main');
  });
})();
